//
//  ViewController.swift
//  Test
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtusername: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBAction func btnlogin(_ sender: Any) {
        
        if txtusername.text == "admin@gmail.com" && password.text == "admin123"
        {
            
            performSegue(withIdentifier: "ElectricityBillViewController", sender: self)
            
        } else {
            print("error")
        }
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

